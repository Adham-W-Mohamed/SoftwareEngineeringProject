package swe425.project.MIUScheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiuSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
