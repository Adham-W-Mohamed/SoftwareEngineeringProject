package swe425.project.MIUScheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiuSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiuSchedulerApplication.class, args);
	}

}
